#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "bf.h"
#include "hash_file.h"
#define MAX_OPEN_FILES 20
#define HASH_SIZE 32

#define CALL_BF(call)       \
{                           \
  BF_ErrorCode code = call; \
  if (code != BF_OK) {         \
    BF_PrintError(code);    \
    return HP_ERROR;        \
  }                         \
}

void hash_function(int, char *);
void hash_to_int(char *, int *, int );

HT_Info *open_files[MAX_OPEN_FILES];

HT_ErrorCode HT_Init() {

  // Create an array for 20 open_filess
  for (int i = 0; i < MAX_OPEN_FILES; i++)
    open_files[i] = NULL;

  return HT_OK;
}

HT_ErrorCode HT_CreateIndex(const char *filename, int depth) {
  
  // Number of initial buckets
  int size = pow(2,depth);

  BF_CreateFile(filename);

  // Create meta-data for hash hash_table
  HT_Info *info = malloc(sizeof(HT_Info));
  info->filename = malloc(sizeof(filename));
  memcpy(info->filename, filename, sizeof(filename));
  info->global_depth = depth;
  
  // Initialize hash hash_table for 'size' buckets
  int *hash_table = malloc(sizeof(int) * size);
  for (int i = 0; i < size; i++)
    hash_table[i] = -1;

  info->hash_table = hash_table;

  // store meta-data to file's array
  for (int i = 0; i < MAX_OPEN_FILES; i++) {
    if (open_files[i] == NULL) {
      open_files[i] = info;
      return HT_OK;
    }
  }
  return HT_ERROR;
}

HT_ErrorCode HT_OpenIndex(const char *fileName, int *indexDesc) {

  int fd;
  
  BF_OpenFile(fileName, &fd); 

  BF_Block *block;
  BF_Block_Init(&block);
  BF_AllocateBlock(fd, block);
  void *data = BF_Block_GetData(block);
  HT_Info *info;
  info = data;
  int i;
  for (i = 0; i < MAX_OPEN_FILES; i++) {
    if (open_files[i] != NULL && !strcmp(open_files[i]->filename, fileName)) {
        info->global_depth = open_files[i]->global_depth;
        *indexDesc = i;
         info->filename = open_files[i]->filename;
         info->fd = fd;
         info->hash_table = open_files[i]->hash_table;
        break;
      }
  }
  BF_Block_SetDirty(block);
  //BF_UnpinBlock(block);
  if (i == MAX_OPEN_FILES)
    return HT_ERROR;    // File not found

  //Create 2^depth empty buckets 
  for (int i = 0; i < pow(2, info->global_depth); i++) {
    BF_Block *block;
    BF_Block_Init(&block);
    BF_AllocateBlock(fd, block);
    void *data = BF_Block_GetData(block);
    Bucket_Info *bucket = data;
    bucket->capacity = (BF_BLOCK_SIZE - sizeof(Bucket_Info)) / sizeof(Record);
    bucket->records = 0;
    bucket->local_depth = info->global_depth;
    int block_id;
    BF_GetBlockCounter(fd, &block_id);
    info->hash_table[i] = block_id-1;
    BF_Block_SetDirty(block);
    BF_UnpinBlock(block);
  }

  return HT_OK;
}

HT_ErrorCode HT_CloseFile(int indexDesc) {
  //insert code here
  //BF_CloseFile(indexDesc);
  return HT_OK;
}

HT_ErrorCode HT_InsertEntry(int indexDesc, Record record) {
  //int bla = 5;
  //HT_PrintAllEntries(indexDesc, &bla);
  // Get record hash value
  //printf("HERE\n");
  int global_depth = open_files[indexDesc]->global_depth;
  char hash[HASH_SIZE];
  hash_function(record.id, hash);
  int index;
  hash_to_int(hash, &index, global_depth);
  //printf("Record %d entered %d with hash = %s\n", record.id, index, hash);

  // Insert record
  HT_Info *info = open_files[indexDesc];
  BF_Block *block;
  BF_Block_Init(&block);
  int block_id = info->hash_table[index];
  BF_GetBlock(info->fd, block_id, block);
  void *data = BF_Block_GetData(block);
  Bucket_Info *bucket = data;
  // 1st case: avalaible space
  if (bucket->records < bucket->capacity) {
    //printf("1st Case:\n");
    memcpy(data + sizeof(Bucket_Info) + bucket->records * sizeof(Record), &record, sizeof(Record));
    (bucket->records)++;
  }
  // 2nd case: no available space
  else if (bucket->local_depth == info->global_depth) {
    //printf("2nd Case:\n");
    // Double the size of the hash table
    int new_size = pow(2, info->global_depth + 1);
    int *new_hash_table = malloc(sizeof(int) * new_size);
    for (int i = 0; i < new_size; i++)
      new_hash_table[i] = info->hash_table[i/2];
    free(info->hash_table);
    info->hash_table = new_hash_table;
    (info->global_depth)++;

    // Create new bucket and insert record
    BF_Block *new_block;
    BF_Block_Init(&new_block);
    BF_AllocateBlock(info->fd, new_block);
    void *new_data = BF_Block_GetData(new_block);
    Bucket_Info *new_bucket = new_data;
    int new_block_id;
    BF_GetBlockCounter(info->fd, &new_block_id);
    new_bucket->local_depth = ++(bucket->local_depth);
    new_bucket->capacity = bucket->capacity;
    new_bucket->records = 0;
    bucket->records = 0;
    new_hash_table[2*index+1] = new_block_id - 1;
    //printf("Creating new block with id =%d\n", new_block_id - 1);

    for (int i = 0; i < bucket->capacity; i++) {
      Record new_record;
      memcpy(&new_record, data + sizeof(Bucket_Info) + sizeof(Record) * i, sizeof(Record));
      char new_hash[HASH_SIZE];
      //printf("ID = %d\n", new_record.id);
      hash_function(new_record.id, new_hash);
      int new_index;
      hash_to_int(new_hash, &new_index, bucket->local_depth);
      //printf("%d\n", new_index);
      //printf("%d\n", index);
      if (new_index == index)
        new_index = index * 2;
      else
        new_index = index * 2 + 1;
      //printf("Record %d entered %d\n" , new_record.id, new_index);
      //printf("New index is = %d\n" , new_index);
      // Re-hash and re-insert
      if (new_hash_table[new_index] == new_block_id - 1) {
        memcpy(new_data + sizeof(Bucket_Info) + new_bucket->records * sizeof(Record), &new_record, sizeof(Record));
        (new_bucket->records)++;
      } else {
        memcpy(data + sizeof(Bucket_Info) + bucket->records * sizeof(Record), &new_record, sizeof(Record));
        (bucket->records)++;
      }
    }

    // Hash and insert the new Record
    int new_index;
    hash_to_int(hash, &new_index, bucket->local_depth);
    if (new_index == index)
        new_index = index * 2;
      else
        new_index = index * 2 + 1;
    //printf("Record %d entered %d\n" , record.id, new_index);
    // Re-hash and re-insert
    if (new_hash_table[new_index] == new_block_id - 1) {
      memcpy(new_data + sizeof(Bucket_Info) + new_bucket->records * sizeof(Record), &record, sizeof(Record));
      (new_bucket->records)++;
    } else {
      memcpy(data + sizeof(Bucket_Info) + bucket->records * sizeof(Record), &record, sizeof(Record));
      (bucket->records)++;
    }

  // for (int i = 0; i < 8; i++) {
  //   printf("NEW ID = %d\n", new_hash_table[i]);
  // }
    BF_Block_SetDirty(new_block);
    BF_UnpinBlock(new_block);
  } 
  else {
    // Create new bucket and insert record
    //printf("3nd Case:\n");
    //printf("Index = %d\n", index);
    BF_Block *new_block;
    BF_Block_Init(&new_block);
    BF_AllocateBlock(info->fd, new_block);
    void *new_data = BF_Block_GetData(new_block);
    Bucket_Info *new_bucket = new_data;
    int new_block_id;
    BF_GetBlockCounter(info->fd, &new_block_id);
    new_bucket->local_depth = ++(bucket->local_depth);
    new_bucket->capacity = bucket->capacity;
    new_bucket->records = 0;
    info->hash_table[index + 1] = new_block_id - 1;
    //printf("Creating new block with id =%d\n", new_block_id - 1);
    bucket->records = 0;
    //printf("Index %d points to block %d\n", index, info->hash_table[index]);
    //printf("Index %d points to block %d\n", index + 1, info->hash_table[index + 1]);
    for (int i = 0; i < bucket->capacity; i++) {
      Record new_record;
      memcpy(&new_record, data + sizeof(Bucket_Info) + sizeof(Record) * i, sizeof(Record));
      char new_hash[HASH_SIZE];
      hash_function(new_record.id, new_hash);
      int new_index;
      hash_to_int(new_hash, &new_index, bucket->local_depth);
      int pos = index % 2; // 0 or 1
      int dig = (new_index >= pow(2, (bucket->local_depth - 1))) ? 1 : 0;  // 0 or 1
      //printf("Position = %d and Digit = %d\n", pos, dig);
      if (pos == dig)
        new_index = index;
      else if (dig > pos)
        new_index = index + 1;
      else
        new_index = index - 1;
      //printf("New index is %d", new_index);
      //printf("Record %d entered %d with hash = %s\n" , new_record.id, new_index, new_hash);
      // Re-hash and re-insert
      if (info->hash_table[new_index] == new_block_id - 1) {
        memcpy(new_data + sizeof(Bucket_Info) + new_bucket->records * sizeof(Record), &new_record, sizeof(Record));
        (new_bucket->records)++;
      } else {
        memcpy(data + sizeof(Bucket_Info) + bucket->records * sizeof(Record), &new_record, sizeof(Record));
        (bucket->records)++;
      }
    }

    // Hash and insert the new Record
    
    //printf("HERE\n");

    int new_index;
    hash_to_int(hash, &new_index, bucket->local_depth);
    int pos = index % 2; // 0 or 1
    int dig = (new_index >= pow(2, (bucket->local_depth - 1))) ? 1 : 0;  // 0 or 1
    //printf("Position = %d and Digit = %d\n", pos, dig);
    if (pos == dig)
      new_index = index;
    else if (dig > pos)
      new_index = index - 1;
    else
      new_index = index + 1;
    // new_index = index;
    //printf("New index is %d", new_index);
    //printf("Record %d entered %d with hash = %s\n" , record.id, new_index, hash);
    if (info->hash_table[new_index] == new_block_id - 1) {
      memcpy(new_data + sizeof(Bucket_Info) + new_bucket->records * sizeof(Record), &record, sizeof(Record));
      (new_bucket->records)++;
    } else {
      memcpy(data + sizeof(Bucket_Info) + bucket->records * sizeof(Record), &record, sizeof(Record));
      (bucket->records)++;
    }
    BF_Block_SetDirty(new_block);
    BF_UnpinBlock(new_block);
  }
  
  BF_Block_SetDirty(block);
  BF_UnpinBlock(block);
  
  return HT_OK;
}

HT_ErrorCode HT_PrintAllEntries(int indexDesc, int *id) {
  
  HT_Info *info = open_files[indexDesc];
  int i, j, count = 0;
  for (i = 0; i < pow(2, info->global_depth) ; i++) {
    BF_Block *block;
    BF_Block_Init(&block);
    BF_GetBlock(info->fd, info->hash_table[i], block);
    void * data = BF_Block_GetData(block);
    Bucket_Info *bucket = data;
    //printf("ID = %d\n", bucket->records);
    for (j = 0 ; j < bucket->records; j++) {
      Record record;
      memcpy(&record, data + sizeof(Bucket_Info) + sizeof(Record) * j,sizeof(Record));
      count++;
    }
    BF_Block_SetDirty(block);
    BF_UnpinBlock(block);
  }
  printf("%d\n", count);
  return HT_OK;
  }

void hash_function(int num, char *key) {
  key[HASH_SIZE - 1] = '\0';
  for (int i = HASH_SIZE - 2; i >= 0; i--, num >>= 1)
    key[HASH_SIZE - 2 - i] = (num & 1) + '0';
}

void hash_to_int(char key[HASH_SIZE], int *index, int depth) {
  *index = 0;
  for (int i = 0; i < depth; i++)
    *index = *index + (key[i] - '0') * (int)pow(2, i);
}
